const site = `{
    "alunos": [
        {
            "nome": " Joao",
            "RGM": "299",
            "avalicaoParcial": 2,
            "exercicio": 2,
            "avaliacaoRegimatal": 2,
            "img": "./imgs/Joao.png" 
        }
    ]
}`


function exibirAlunos(){

    const objs = JSON.parse(site)

    // console.log(objs)
    //console.log(objs.alunos[0])

    let resultado = document.getElementById("resultado")

    objs.alunos.forEach(element => {
        console.log(element)

        resultado.innerHTML +=
        `<p>Nome: ${element.nome}</p>
        <img src="${element,img}"Joao.png alt="">`
    });

}
