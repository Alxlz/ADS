const x = 10
let y = 10

console.log("Adição -> " + (x + 10))
console.log("Subtração -> " +  (x - 10))
console.log("Multiplicação -> " +  (x * 10) )
console.log("Divisão -> " + (x / 10))
console.log("Expoente -> " + (x**2))
console.log("Módulo -> " + (x%2))
console.log("Incremento anterior -> " + (++y) )
console.log("Incremento posterior -> " + (y++) )
console.log("Incremento posterior 02 -> " + (y) )
console.log("Decremento anterior -> " + (--y))
console.log("Decremento posterior -> " + (y--) )
console.log("Decremento posterior 02 -> " + (y) )