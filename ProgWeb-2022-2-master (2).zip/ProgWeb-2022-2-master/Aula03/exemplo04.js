
let a = "Olá, "
let b = "tudo bem?"
let x = a + b

console.log(x)


let c = 4
let d = "a"
let y = c + d

console.log(y)

let e = "5"
let f = "3"
let z = e + f

console.log(z)


let g = 15
let h = 20

console.log(`A soma de ${g} e ${h} é igual a ${g + h}`)

console.log("Resultado: " + (g + h))
console.log('Resultado: ' + (g + h))


console.log("Soma com conversão: " + (parseInt(e) + parseInt(f)))