
let x = "Biscoito"

console.log(x.length)

console.log(x.charAt(3))

console.log(x.charCodeAt(3))


console.log(x.indexOf("oito", 5))


console.log(x.substring(4, 8))


console.log(x.toLowerCase())


console.log(x.toUpperCase())

let y = "Ola como vai você ?"
console.log(y.split(" "))

console.log()